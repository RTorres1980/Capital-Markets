# Streamlit app scaffold - simple investor summary viewer
# Run with: streamlit run src/dashboard_example.py
import streamlit as st
import pandas as pd

st.set_page_config(page_title='Investor Summary', layout='wide')
st.title('Investor Services — Summary Dashboard (Demo)')

@st.cache_data
def load_data(path='reports/investor_summary.xlsx'):
    df = pd.read_excel(path, sheet_name='Investor_Summary')
    cp = pd.read_excel(path, sheet_name='By_Counterparty')
    return df, cp

try:
    summ, cp = load_data()
    st.subheader('Top Investors by Total Amount')
    st.dataframe(summ.sort_values('total_amount', ascending=False).head(10))
    st.subheader('Counterparty Aggregates')
    st.dataframe(cp)
except Exception as e:
    st.error(f'Could not load reports — run src/reporting.py to generate sample reports. Error: {e}')
