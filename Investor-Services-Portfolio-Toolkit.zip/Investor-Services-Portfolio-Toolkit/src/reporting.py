#!/usr/bin/env python3
"""Simple reporting script: reads transactions CSV and creates investor-level summaries and Excel workbook."""
import argparse
import pandas as pd
import numpy as np

def load_tx(path):
    df = pd.read_csv(path, parse_dates=['trade_date'])
    return df

def investor_summary(df):
    # compute totals by investor
    summ = df.groupby(['investor_id','investor_name']).agg(
        total_trades=('trade_id','count'),
        total_amount=('amount','sum'),
        avg_trade_amount=('amount','mean')
    ).reset_index()
    # P&L-ish proxy: buys negative, sells positive
    df['signed_amount'] = df.apply(lambda r: r['amount'] if r['tx_type']=='SELL' else (-r['amount'] if r['tx_type']=='BUY' else 0), axis=1)
    pnl = df.groupby('investor_id').signed_amount.sum().reset_index().rename(columns={'signed_amount':'net_trade_flow'})
    summ = summ.merge(pnl, on='investor_id', how='left')
    return summ

def per_counterparty(df):
    cp = df.groupby('counterparty').agg(
        trades=('trade_id','count'),
        amount=('amount','sum')
    ).reset_index().sort_values('amount',ascending=False)
    return cp

def write_excel(summ, cp, out):
    with pd.ExcelWriter(out, engine='openpyxl') as writer:
        summ.to_excel(writer, sheet_name='Investor_Summary', index=False)
        cp.to_excel(writer, sheet_name='By_Counterparty', index=False)
    print('Wrote', out)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--in', dest='inp', default='data/sample_transactions.csv')
    p.add_argument('--out', default='reports/investor_summary.xlsx')
    args = p.parse_args()
    df = load_tx(args.inp)
    summ = investor_summary(df)
    cp = per_counterparty(df)
    write_excel(summ, cp, args.out)

if __name__=='__main__':
    main()
