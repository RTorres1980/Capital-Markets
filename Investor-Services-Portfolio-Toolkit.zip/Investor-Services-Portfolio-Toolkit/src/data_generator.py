#!/usr/bin/env python3
"""Generate synthetic investor transaction data for demos."""
import argparse, csv, random, datetime, uuid
import pandas as pd
import numpy as np

def generate(n_investors=10, n_tx=1000, seed=42):
    random.seed(seed)
    np.random.seed(seed)
    investors = [f"INV-{i:03d}" for i in range(1, n_investors+1)]
    investor_names = [f"Investor {i}" for i in range(1, n_investors+1)]
    asset_types = ['Equity','Fixed Income','Cash','RealEstate','Alternative']
    rows = []
    start = datetime.datetime(2024,1,1)
    for _ in range(n_tx):
        inv = random.choice(investors)
        name = investor_names[int(inv.split('-')[1])-1]
        dt = start + datetime.timedelta(days=random.randint(0,540))
        tx_type = random.choices(['BUY','SELL','COUPON','DIVIDEND','FEE','DEPOSIT','WITHDRAWAL'], weights=[25,25,10,10,5,15,10])[0]
        asset = random.choice(asset_types)
        quantity = round(np.random.exponential(1000),2)
        price = round(abs(np.random.normal(50,20)),2)
        amount = round(quantity * price if tx_type in ['BUY','SELL'] else np.random.uniform(10,5000),2)
        counterparty = random.choice(['CIBC','BMO','Bank of America','Custodian X','Custodian Y','Internal'])
        trade_id = str(uuid.uuid4())
        rows.append({
            'investor_id': inv,
            'investor_name': name,
            'trade_date': dt.strftime('%Y-%m-%d'),
            'tx_type': tx_type,
            'asset_type': asset,
            'quantity': quantity,
            'price': price,
            'amount': amount,
            'counterparty': counterparty,
            'trade_id': trade_id
        })
    df = pd.DataFrame(rows)
    return df

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', default='data/sample_transactions.csv')
    p.add_argument('--n_investors', type=int, default=10)
    p.add_argument('--n_tx', type=int, default=1000)
    args = p.parse_args()
    df = generate(args.n_investors, args.n_tx)
    df.to_csv(args.out, index=False)
    print('Wrote', args.out)

if __name__=='__main__':
    main()
