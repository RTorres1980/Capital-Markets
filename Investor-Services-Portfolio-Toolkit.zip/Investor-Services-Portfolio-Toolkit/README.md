# Investor-Services-Portfolio-Toolkit

**Purpose:** A compact, downloadable repository demonstrating practical investor servicing and capital markets workflows: data ingestion, investor-level reporting, post-transaction reconciliation, and a starter dashboard.  Ideal for interviews or portfolio demonstrations for roles like *Sr. Associate, Investor Services - Capital Markets*.

**What's included**
- `src/data_generator.py` — synthetic investor transaction data generator (CSV output).
- `data/sample_transactions.csv` — sample transaction dataset (generated).
- `src/reporting.py` — script to produce investor-level summaries and an Excel workbook report (in `reports/`).
- `reports/investor_summary.xlsx` — generated investor summary workbook.
- `src/dashboard_example.py` — starter Streamlit app that reads the reports and visualizes key metrics (run with `streamlit run`).
- `README.md`, `LICENSE`, `.gitignore` — repo metadata.

**How this maps to Capital Markets / Investor Services**
- Shows how to ingest trade and cashflow data, compute investor-level balances, P&L, and produce reconciliation-friendly outputs.
- Demonstrates generation of investor reporting workbooks that can be shared with internal teams, auditors, and external investors.
- Includes a simple dashboard scaffold for presenting deal-level performance and investor exposures.
- Code is well-commented to make the steps clear for technical and non-technical interviewers.

**Quick start**
```bash
# 1. Generate sample data (or use provided CSV)
python src/data_generator.py --out data/sample_transactions.csv --n_investors 10 --n_tx 1000

# 2. Create reporting workbook
python src/reporting.py --in data/sample_transactions.csv --out reports/investor_summary.xlsx

# 3. Launch the example dashboard (optional)
pip install streamlit pandas openpyxl plotly
streamlit run src/dashboard_example.py
```

**Files of interest**: `src/reporting.py` (shows reconciliation-ready summaries), `reports/investor_summary.xlsx` (example deliverable), and `src/dashboard_example.py` (investor-facing visualization scaffold).

---
Generated on 2025-10-23
